﻿namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Services
{
    public class Relatorio
    {
    }
}
