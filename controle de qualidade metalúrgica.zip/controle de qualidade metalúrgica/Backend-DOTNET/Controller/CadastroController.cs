﻿namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Controller
{
    public class CadastroController
    {
    }
}
