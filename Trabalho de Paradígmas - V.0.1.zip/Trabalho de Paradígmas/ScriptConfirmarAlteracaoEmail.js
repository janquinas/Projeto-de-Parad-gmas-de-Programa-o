document.addEventListener('DOMContentLoaded', function() {
    // Simular código de verificação (em produção viria do backend)
    const codigoVerificacao = Math.floor(100000 + Math.random() * 900000).toString();
    let tempoRestante = 120; // 2 minutos em segundos
    let timerInterval;
    
    // Mostrar email de destino
    const emailTemporario = sessionStorage.getItem('emailTemporario') || 'seu_novo_email@exemplo.com';
    document.getElementById('email-destino').textContent = emailTemporario;
    
    // Iniciar timer
    iniciarTimer();
    
    // Auto-foco no input
    document.getElementById('codigo-verificacao').focus();
    
    function iniciarTimer() {
        timerInterval = setInterval(function() {
            tempoRestante--;
            
            const minutos = Math.floor(tempoRestante / 60);
            const segundos = tempoRestante % 60;
            
            document.getElementById('timer').textContent = 
                `Reenviar código em: ${minutos}:${segundos.toString().padStart(2, '0')}`;
            
            if (tempoRestante <= 0) {
                clearInterval(timerInterval);
                document.getElementById('timer').style.display = 'none';
                document.getElementById('reenviar-link').style.display = 'inline';
            }
        }, 1000);
    }
    
    window.reenviarCodigo = function() {
        // Resetar timer
        tempoRestante = 120;
        document.getElementById('timer').style.display = 'block';
        document.getElementById('reenviar-link').style.display = 'none';
        
        // Simular reenvio do código
        alert('Código reenviado para: ' + emailTemporario);
        
        // Reiniciar timer
        iniciarTimer();
    };
    
    document.getElementById('confirmar-codigo-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const codigoInserido = document.getElementById('codigo-verificacao').value;
        
        // Reset error
        document.getElementById('codigo-error').style.display = 'none';
        
        if (codigoInserido.length !== 6) {
            document.getElementById('codigo-error').textContent = 'O código deve ter 6 dígitos.';
            document.getElementById('codigo-error').style.display = 'block';
            return;
        }
        
        if (codigoInserido !== codigoVerificacao) {
            document.getElementById('codigo-error').textContent = 'Código incorreto. Tente novamente.';
            document.getElementById('codigo-error').style.display = 'block';
            return;
        }
        
        // Código correto - alterar email
        const novoEmail = sessionStorage.getItem('novoEmail');
        
        // Simular alteração bem-sucedida
        alert('Email alterado com sucesso para: ' + novoEmail);
        
        // Limpar sessionStorage
        sessionStorage.removeItem('novoEmail');
        sessionStorage.removeItem('emailTemporario');
        
        // Redirecionar para perfil
        window.location.href = 'IndexUsuarioComum.html';
    });
    
    // Auto avançar entre dígitos (melhoria UX)
    document.getElementById('codigo-verificacao').addEventListener('input', function(e) {
        if (this.value.length === 6) {
            document.getElementById('confirmar-codigo-form').dispatchEvent(new Event('submit'));
        }
    });
});