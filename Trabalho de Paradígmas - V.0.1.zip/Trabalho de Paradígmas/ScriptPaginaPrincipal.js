document.addEventListener('DOMContentLoaded', function() {
    // Inicializar dados da página
    carregarDadosDashboard();
    carregarTabelaPedidos();
    carregarNotificacoes();
    configurarInteracoes();
    
    // Fechar popup ao clicar fora
    document.addEventListener('click', function(e) {
        const popup = document.getElementById('notification-popup');
        const notifBtn = document.querySelector('.header-button[title="Notificações"]');
        
        if (popup && !popup.contains(e.target) && notifBtn && !notifBtn.contains(e.target)) {
            popup.style.display = 'none';
        }
    });
});

function carregarDadosDashboard() {
    // Dados simulados do dashboard
    const dadosDashboard = {
        produtividade: 85,
        meta: 92,
        defeitos: 2.3,
        oee: 78.5
    };

    // Atualizar métricas
    const produtividadeElement = document.querySelector('#produtividade-block .metric-value');
    const metaElement = document.querySelector('#meta-block .metric-value');
    const defeitosElement = document.querySelector('#defeitos-taxa-block .metric-value');
    const oeeElement = document.querySelector('#oee-block .metric-value');

    if (produtividadeElement) produtividadeElement.textContent = dadosDashboard.produtividade + '%';
    if (metaElement) metaElement.textContent = dadosDashboard.meta + '%';
    if (defeitosElement) defeitosElement.textContent = dadosDashboard.defeitos + '%';
    if (oeeElement) oeeElement.textContent = dadosDashboard.oee + '%';
}

function carregarTabelaPedidos() {
    const dadosPedidos = [
        {
            id: 'PED-001',
            empresa: 'Metalúrgica ABC',
            material: 'Aço Inox / 2mm',
            data: '15/02 - 20/02',
            qualidade: '95%',
            status: 'Em Produção'
        },
        {
            id: 'PED-002',
            empresa: 'Indústria XYZ',
            material: 'Alumínio / 3mm',
            data: '18/02 - 25/02',
            qualidade: '98%',
            status: 'Planejado'
        },
        {
            id: 'PED-003',
            empresa: 'Comércio DEF',
            material: 'Cobre / 1.5mm',
            data: '10/02 - 15/02',
            qualidade: '92%',
            status: 'Concluído'
        },
        {
            id: 'PED-004',
            empresa: 'Metalúrgica ABC',
            material: 'Aço Carbono / 4mm',
            data: '20/02 - 28/02',
            qualidade: '-',
            status: 'Pendente'
        }
    ];

    const tabelaDados = document.getElementById('tabela-dados');
    if (!tabelaDados) return;
    
    dadosPedidos.forEach(pedido => {
        const linha = document.createElement('div');
        linha.className = 'linha-tabela';
        
        linha.innerHTML = `
            <div>${pedido.id}</div>
            <div>${pedido.empresa}</div>
            <div>${pedido.material}</div>
            <div>${pedido.data}</div>
            <div>${pedido.qualidade}</div>
            <div class="status-${pedido.status.toLowerCase().replace(' ', '-')}">${pedido.status}</div>
        `;
        
        tabelaDados.appendChild(linha);
    });
}

function carregarNotificacoes() {
    const notificacoes = [
        {
            titulo: 'Pedido Concluído',
            mensagem: 'O pedido PED-003 foi finalizado com sucesso.',
            tempo: 'Há 2 horas',
            lida: false
        },
        {
            titulo: 'Alerta de Qualidade',
            mensagem: 'Taxa de defeitos acima do esperado no turno da manhã.',
            tempo: 'Há 5 horas',
            lida: false
        },
        {
            titulo: 'Manutenção Preventiva',
            mensagem: 'Manutenção agendada para sábado às 08:00.',
            tempo: 'Ontem',
            lida: true
        }
    ];

    const notificationList = document.getElementById('notification-list');
    const badge = document.getElementById('notification-badge');
    
    if (!notificationList) return;

    const hasUnread = notificacoes.some(notif => !notif.lida);
    const unreadCount = notificacoes.filter(notif => !notif.lida).length;
    
    // Atualizar badge
    if (badge) {
        if (unreadCount > 0) {
            badge.textContent = unreadCount;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }

    if (notificacoes.length === 0) {
        notificationList.innerHTML = '<div class="no-notifications">Nenhuma notificação</div>';
        return;
    }

    notificationList.innerHTML = notificacoes.map(notif => `
        <div class="notification-item ${notif.lida ? 'lida' : 'nao-lida'}">
            <div class="notification-title">${notif.titulo}</div>
            <div class="notification-message">${notif.mensagem}</div>
            <div class="notification-time">${notif.tempo}</div>
        </div>
    `).join('');
}

function toggleNotificacoes() {
    const popup = document.getElementById('notification-popup');
    if (!popup) return;
    
    const isVisible = popup.style.display === 'block';
    popup.style.display = isVisible ? 'none' : 'block';
    
    // Marcar notificações como lidas quando abrir o popup
    if (!isVisible) {
        const badge = document.getElementById('notification-badge');
        if (badge) {
            badge.style.display = 'none';
        }
    }
}

function irParaPerfil() {
    window.location.href = 'IndexUsuarioComum.html';
}

function irParaConfiguracoes() {
    window.location.href = 'IndexConfiguracoes.html';
}

function sair() {
    if (confirm('Tem certeza que deseja sair?')) {
        // Limpar dados de sessão
        sessionStorage.clear();
        localStorage.removeItem('userEmail');
        
        // Redirecionar para login
        window.location.href = 'IndexLogin.html';
    }
}

function configurarInteracoes() {
    // Adicionar estilos de status
    const styles = `
        .status-em-produção { color: #d4a017; font-weight: bold; }
        .status-planejado { color: #17a2d4; font-weight: bold; }
        .status-concluído { color: #17d46f; font-weight: bold; }
        .status-pendente { color: #d41717; font-weight: bold; }
        .notification-item.nao-lida { border-left-color: #ff4444; }
        .notification-item.lida { border-left-color: #666; }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = styles;
    document.head.appendChild(styleSheet);

    // Configurar hover nos gráficos
    const chartPlaceholders = document.querySelectorAll('.chart-placeholder');
    chartPlaceholders.forEach(chart => {
        chart.addEventListener('click', function() {
            alert('Gráfico clicado! Em uma implementação real, isso expandiria o gráfico.');
        });
    });

    // Atualizar dados a cada 30 segundos (simulação)
    setInterval(atualizarDadosTempoReal, 30000);
}

function atualizarDadosTempoReal() {
    // Simular atualização de dados em tempo real
    const variacao = (Math.random() - 0.5) * 2;
    const produtividadeElement = document.querySelector('#produtividade-block .metric-value');
    
    if (produtividadeElement) {
        const produtividadeAtual = parseFloat(produtividadeElement.textContent);
        const novaProdutividade = Math.max(70, Math.min(95, produtividadeAtual + variacao));
        
        produtividadeElement.textContent = novaProdutividade.toFixed(1) + '%';
        produtividadeElement.style.color = novaProdutividade > produtividadeAtual ? '#17d46f' : '#d41717';
        
        setTimeout(() => {
            produtividadeElement.style.color = '#d4a017';
        }, 1000);
    }
}