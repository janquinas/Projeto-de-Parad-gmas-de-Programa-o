document.addEventListener('DOMContentLoaded', function() {
    let dataSelecionada = null;
    let turnoSelecionado = null;
    let dataAtual = new Date();
    
    const calendarioMes = document.getElementById('calendario-mes');
    const calendarioGrid = document.getElementById('calendario-grid');
    const btnMesAnterior = document.getElementById('btn-mes-anterior');
    const btnMesProximo = document.getElementById('btn-mes-proximo');
    const turnoInfo = document.getElementById('turno-info');
    const turnoSelecionadoText = document.getElementById('turno-selecionado-text');
    const turnoDetalhesText = document.getElementById('turno-detalhes-text');
    const btnConfirmar = document.getElementById('btn-confirmar');
    const form = document.getElementById('alterar-turno-form');
    
    // Inicializar calendário
    atualizarCalendario();
    
    // Event listeners para navegação do calendário
    btnMesAnterior.addEventListener('click', function() {
        dataAtual.setMonth(dataAtual.getMonth() - 1);
        atualizarCalendario();
    });
    
    btnMesProximo.addEventListener('click', function() {
        dataAtual.setMonth(dataAtual.getMonth() + 1);
        atualizarCalendario();
    });
    
    // Event listeners para os botões de horário
    document.querySelectorAll('.horario-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            // Remover seleção anterior
            document.querySelectorAll('.horario-btn').forEach(b => {
                b.classList.remove('selecionado');
            });
            
            // Adicionar seleção atual
            this.classList.add('selecionado');
            turnoSelecionado = this.getAttribute('data-horario');
            
            atualizarInfoTurno();
        });
    });
    
    // Event listener para o formulário
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!dataSelecionada || !turnoSelecionado) {
            alert('Por favor, selecione uma data e um turno.');
            return;
        }
        
        // Formatar data para exibição
        const dataFormatada = formatarData(dataSelecionada);
        
        // Simular salvamento
        alert(`Turno alterado com sucesso!\n\nData: ${dataFormatada}\nTurno: ${turnoSelecionado}`);
        
        // Redirecionar de volta ao perfil
        setTimeout(() => {
            window.location.href = 'IndexUsuarioComum.html';
        }, 2000);
    });
    
    function atualizarCalendario() {
        const ano = dataAtual.getFullYear();
        const mes = dataAtual.getMonth();
        
        // Atualizar cabeçalho do mês
        const nomesMeses = [
            'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
            'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
        ];
        calendarioMes.textContent = `${nomesMeses[mes]} ${ano}`;
        
        // Limpar grid do calendário
        calendarioGrid.innerHTML = '';
        
        // Primeiro dia do mês
        const primeiroDia = new Date(ano, mes, 1);
        // Último dia do mês
        const ultimoDia = new Date(ano, mes + 1, 0);
        // Dia da semana do primeiro dia (0 = Domingo, 6 = Sábado)
        const primeiroDiaSemana = primeiroDia.getDay();
        
        // Adicionar dias vazios no início
        for (let i = 0; i < primeiroDiaSemana; i++) {
            const diaVazio = document.createElement('div');
            diaVazio.className = 'dia inativo';
            calendarioGrid.appendChild(diaVazio);
        }
        
        // Adicionar dias do mês
        for (let dia = 1; dia <= ultimoDia.getDate(); dia++) {
            const diaElement = document.createElement('div');
            diaElement.className = 'dia';
            diaElement.textContent = dia;
            
            const dataDia = new Date(ano, mes, dia);
            
            // Verificar se é hoje
            const hoje = new Date();
            if (dataDia.toDateString() === hoje.toDateString()) {
                diaElement.style.borderColor = '#d4a017';
            }
            
            // Verificar se é fim de semana
            if (dataDia.getDay() === 0 || dataDia.getDay() === 6) {
                diaElement.style.color = '#ff4444';
            }
            
            // Event listener para seleção de dia
            diaElement.addEventListener('click', function() {
                // Remover seleção anterior
                document.querySelectorAll('.dia').forEach(d => {
                    d.classList.remove('selecionado');
                });
                
                // Adicionar seleção atual
                this.classList.add('selecionado');
                dataSelecionada = dataDia;
                
                atualizarInfoTurno();
            });
            
            calendarioGrid.appendChild(diaElement);
        }
    }
    
    function atualizarInfoTurno() {
        if (dataSelecionada && turnoSelecionado) {
            const dataFormatada = formatarData(dataSelecionada);
            
            turnoSelecionadoText.textContent = `Turno selecionado: ${turnoSelecionado}`;
            turnoDetalhesText.textContent = `Data: ${dataFormatada}`;
            
            turnoInfo.style.display = 'block';
            btnConfirmar.disabled = false;
        } else {
            turnoInfo.style.display = 'none';
            btnConfirmar.disabled = true;
        }
    }
    
    function formatarData(data) {
        const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
        const meses = [
            'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
            'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
        ];
        
        const diaSemana = diasSemana[data.getDay()];
        const dia = data.getDate();
        const mes = meses[data.getMonth()];
        const ano = data.getFullYear();
        
        return `${diaSemana}, ${dia} de ${mes} de ${ano}`;
    }
    
    // Selecionar a data de hoje por padrão
    setTimeout(() => {
        const hojeElement = calendarioGrid.querySelector('.dia:not(.inativo)');
        if (hojeElement) {
            hojeElement.click();
        }
    }, 100);
});