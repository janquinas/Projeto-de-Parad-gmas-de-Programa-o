document.addEventListener('DOMContentLoaded', function() {
    // Configurar navegação e funcionalidades da tela de configurações
    configurarNavegacao();
});

function configurarNavegacao() {
    // Adicionar eventos aos links de configuração
    const links = document.querySelectorAll('.botao-link');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Para o link "Deletar Conta", adicionar confirmação extra
            if (this.classList.contains('deletar')) {
                e.preventDefault();
                const confirmar = confirm('Você está prestes a acessar a página de deleção de conta. Esta ação é irreversível. Deseja continuar?');
                if (confirmar) {
                    window.location.href = this.getAttribute('href');
                }
            }
        });
    });
}

function voltar() {
    if (document.referrer && document.referrer.includes(window.location.hostname)) {
        window.history.back();
    } else {
        window.location.href = 'IndexPaginaPrincipal.html';
    }
}