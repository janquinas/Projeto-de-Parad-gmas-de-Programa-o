document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('alterar-email-form');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const novoEmail = document.getElementById('novo-email').value;
        const confirmarEmail = document.getElementById('confirmar-email').value;
        const senha = document.getElementById('senha').value;
        
        // Reset errors
        document.getElementById('email-error').style.display = 'none';
        document.getElementById('confirmar-error').style.display = 'none';
        document.getElementById('senha-error').style.display = 'none';
        
        let isValid = true;
        
        // Validar email
        if (!validarEmail(novoEmail)) {
            document.getElementById('email-error').textContent = 'Por favor, insira um email válido.';
            document.getElementById('email-error').style.display = 'block';
            isValid = false;
        }
        
        // Validar confirmação de email
        if (novoEmail !== confirmarEmail) {
            document.getElementById('confirmar-error').textContent = 'Os emails não coincidem.';
            document.getElementById('confirmar-error').style.display = 'block';
            isValid = false;
        }
        
        // Validar senha (simulação)
        if (senha.length < 8) {
            document.getElementById('senha-error').textContent = 'Senha deve ter pelo menos 6 caracteres.';
            document.getElementById('senha-error').style.display = 'block';
            isValid = false;
        }
        
        if (isValid) {
            // Simular envio do código
            alert('Código de verificação enviado para: ' + novoEmail);
            
            // Salvar dados temporariamente
            sessionStorage.setItem('novoEmail', novoEmail);
            sessionStorage.setItem('emailTemporario', novoEmail);
            
            // Redirecionar para página de confirmação
            window.location.href = 'IndexConfirmarAlteracaoEmail.html';
        }
    });
    
    function validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    
    // Validação em tempo real
    document.getElementById('confirmar-email').addEventListener('input', function() {
        const novoEmail = document.getElementById('novo-email').value;
        const confirmarEmail = this.value;
        
        if (confirmarEmail && novoEmail !== confirmarEmail) {
            document.getElementById('confirmar-error').textContent = 'Os emails não coincidem.';
            document.getElementById('confirmar-error').style.display = 'block';
        } else {
            document.getElementById('confirmar-error').style.display = 'none';
        }
    });
});