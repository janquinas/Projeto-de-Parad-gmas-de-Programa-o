document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form-esqueceu-senha');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const email = document.getElementById('email').value;
        
        // Validação básica de email
        if (!validarEmail(email)) {
            alert('Por favor, insira um e-mail válido.');
            return;
        }
        
        // Simulação de envio de código
        alert('Código de recuperação enviado para: ' + email);
        
        // Salvar email temporariamente
        sessionStorage.setItem('emailRecuperacao', email);
        
        // Redirecionar para página de verificação
        window.location.href = 'IndexVerificacaoEmail.html';
    });
    
    function validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
});