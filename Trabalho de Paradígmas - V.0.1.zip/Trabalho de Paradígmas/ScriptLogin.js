document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form-login');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const usuario = document.getElementById('usuario').value;
        const senha = document.getElementById('senha').value;
        
        // Validação básica
        if (!validarEmail(usuario)) {
            alert('Por favor, insira um email válido.');
            return;
        }
        
        if (senha.length < 8) {
            alert('A senha deve ter pelo menos 8 caracteres.');
            return;
        }
        
        // Simulação de login bem-sucedido
        alert('Login realizado com sucesso!');
        
        // Redirecionar para página principal
        window.location.href = 'IndexUsuarioComum.html';
    });
    
    function validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
});