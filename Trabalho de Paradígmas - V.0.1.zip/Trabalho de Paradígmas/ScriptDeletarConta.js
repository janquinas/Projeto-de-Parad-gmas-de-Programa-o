class DeletarContaManager {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.preencherEmailUsuario();
        this.validarFormulario();
    }

    setupEventListeners() {
        const form = document.getElementById('deletar-conta-form');
        if (form) {
            form.addEventListener('submit', (e) => {
                this.handleSubmit(e);
            });
        }

        const emailInput = document.getElementById('confirmar-email');
        const senhaInput = document.getElementById('confirmar-senha');
        const checkbox = document.getElementById('confirmar-delecao');

        if (emailInput) {
            emailInput.addEventListener('input', () => {
                this.validarEmail();
                this.validarFormulario();
            });
        }

        if (senhaInput) {
            senhaInput.addEventListener('input', () => {
                this.validarSenha();
                this.validarFormulario();
            });
        }

        if (checkbox) {
            checkbox.addEventListener('change', () => {
                this.validarFormulario();
            });
        }
    }

    preencherEmailUsuario() {
        try {
            const userEmail = this.obterEmailUsuario();
            const emailInput = document.getElementById('confirmar-email');
            if (emailInput && userEmail) {
                emailInput.value = userEmail;
                this.validarEmail();
            }
        } catch (error) {
            console.warn('Não foi possível preencher o email automaticamente:', error);
        }
    }

    obterEmailUsuario() {
        // Ordem de prioridade para obter o email
        return localStorage.getItem('userEmail') || 
               sessionStorage.getItem('userEmail') ||
               'joao.silva@empresa.com'; // Fallback para demonstração
    }

    validarEmail() {
        const emailInput = document.getElementById('confirmar-email');
        if (!emailInput) return false;

        const email = emailInput.value.trim();
        const userEmail = this.obterEmailUsuario();
        const campoGrupo = emailInput.closest('.campo-grupo') || emailInput.parentElement;
        
        if (!email) {
            this.marcarCampoInvalido(campoGrupo, 'Email é obrigatório');
            return false;
        }

        if (email !== userEmail) {
            this.marcarCampoInvalido(campoGrupo, 'Email não corresponde ao email da conta');
            return false;
        }

        if (!this.validarFormatoEmail(email)) {
            this.marcarCampoInvalido(campoGrupo, 'Formato de email inválido');
            return false;
        }

        this.marcarCampoValido(campoGrupo);
        return true;
    }

    validarSenha() {
        const senhaInput = document.getElementById('confirmar-senha');
        if (!senhaInput) return false;

        const senha = senhaInput.value;
        const campoGrupo = senhaInput.closest('.campo-grupo') || senhaInput.parentElement;
        
        if (!senha) {
            this.marcarCampoInvalido(campoGrupo, 'Senha é obrigatória');
            return false;
        }

        if (senha.length < 8) {
            this.marcarCampoInvalido(campoGrupo, 'Senha muito curta');
            return false;
        }

        this.marcarCampoValido(campoGrupo);
        return true;
    }

    validarConfirmacao() {
        const checkbox = document.getElementById('confirmar-delecao');
        return checkbox ? checkbox.checked : false;
    }

    validarFormulario() {
        const isEmailValid = this.validarEmail();
        const isSenhaValid = this.validarSenha();
        const isConfirmacaoValid = this.validarConfirmacao();
        
        const btnDeletar = document.querySelector('.btn-delete');
        const isFormValid = isEmailValid && isSenhaValid && isConfirmacaoValid;
        
        if (btnDeletar) {
            btnDeletar.disabled = !isFormValid;
        }
        
        return isFormValid;
    }

    validarFormatoEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    marcarCampoInvalido(campoGrupo, mensagem) {
        campoGrupo.classList.remove('valido');
        campoGrupo.classList.add('invalido');
        
        // Remover tooltip anterior se existir
        const tooltipExistente = campoGrupo.querySelector('.error-tooltip');
        if (tooltipExistente) {
            tooltipExistente.remove();
        }
        
        // Adicionar tooltip de erro
        const tooltip = document.createElement('div');
        tooltip.className = 'error-tooltip';
        tooltip.textContent = mensagem;
        tooltip.style.cssText = `
            color: #ff4444;
            font-size: 0.8rem;
            margin-top: 5px;
            padding: 5px;
            background: rgba(255, 68, 68, 0.1);
            border-radius: 3px;
            border-left: 3px solid #ff4444;
        `;
        
        campoGrupo.appendChild(tooltip);
    }

    marcarCampoValido(campoGrupo) {
        campoGrupo.classList.remove('invalido');
        campoGrupo.classList.add('valido');
        
        // Remover tooltip de erro se existir
        const tooltipExistente = campoGrupo.querySelector('.error-tooltip');
        if (tooltipExistente) {
            tooltipExistente.remove();
        }
    }

    async handleSubmit(event) {
        event.preventDefault();
        
        if (!this.validarFormulario()) {
            this.mostrarMensagem('Por favor, corrija os erros no formulário antes de continuar.', 'erro');
            return;
        }

        const confirmacaoFinal = await this.mostrarConfirmacaoFinal();
        
        if (confirmacaoFinal) {
            await this.processarDelecaoConta();
        }
    }

    mostrarConfirmacaoFinal() {
        return new Promise((resolve) => {
            const modal = this.criarModalConfirmacao();
            document.body.appendChild(modal);
            
            const btnConfirmar = modal.querySelector('#btn-confirmar-delecao');
            const btnCancelar = modal.querySelector('#btn-cancelar-delecao');
            
            btnConfirmar.onclick = () => {
                modal.remove();
                resolve(true);
            };
            
            btnCancelar.onclick = () => {
                modal.remove();
                resolve(false);
            };
            
            // Fechar modal ao clicar fora
            modal.onclick = (e) => {
                if (e.target === modal) {
                    modal.remove();
                    resolve(false);
                }
            };
        });
    }

    criarModalConfirmacao() {
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        `;
        
        modal.innerHTML = `
            <div style="
                background: #1c1c1c;
                padding: 30px;
                border-radius: 10px;
                border: 2px solid #8B0000;
                max-width: 400px;
                width: 90%;
                text-align: center;
            ">
                <div style="font-size: 3rem; margin-bottom: 20px;">🚨</div>
                <h3 style="color: #8B0000; margin-bottom: 15px;">CONFIRMAÇÃO FINAL</h3>
                <p style="color: #ff6b6b; line-height: 1.5; margin-bottom: 25px;">
                    <strong>ATENÇÃO: Esta ação é PERMANENTE e IRREVERSÍVEL!</strong><br><br>
                    Você está prestes a deletar permanentemente sua conta e todos os dados associados.
                </p>
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button id="btn-cancelar-delecao" style="
                        padding: 12px 25px;
                        background: transparent;
                        color: #ffffff;
                        border: 1px solid #d4a017;
                        border-radius: 6px;
                        cursor: pointer;
                        font-weight: bold;
                    ">Cancelar</button>
                    <button id="btn-confirmar-delecao" style="
                        padding: 12px 25px;
                        background: #8B0000;
                        color: white;
                        border: none;
                        border-radius: 6px;
                        cursor: pointer;
                        font-weight: bold;
                    ">Confirmar Deleção</button>
                </div>
            </div>
        `;
        
        return modal;
    }

    async processarDelecaoConta() {
        this.mostrarLoading();
        
        try {
            // Simular processo de deleção
            await this.simularDelecaoAPI();
            
            // Limpar dados do usuário
            this.limparDadosUsuario();
            
            // Mostrar mensagem de sucesso
            this.mostrarMensagemSucesso();
            
        } catch (error) {
            this.ocultarLoading();
            this.mostrarMensagem('Erro ao deletar conta: ' + error.message, 'erro');
        }
    }

    async simularDelecaoAPI() {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simular uma falha aleatória (10% de chance) para demonstração
                if (Math.random() < 0.1) {
                    reject(new Error('Falha na conexão com o servidor. Tente novamente.'));
                } else {
                    resolve({ success: true });
                }
            }, 2000);
        });
    }

    mostrarLoading() {
        const loadingOverlay = document.createElement('div');
        loadingOverlay.className = 'loading-overlay';
        loadingOverlay.innerHTML = `
            <div class="loading-spinner"></div>
            <div class="loading-text">Deletando sua conta...</div>
        `;
        document.body.appendChild(loadingOverlay);
    }

    ocultarLoading() {
        const loadingOverlay = document.querySelector('.loading-overlay');
        if (loadingOverlay) {
            loadingOverlay.remove();
        }
    }

    limparDadosUsuario() {
        // Limpar todos os dados de sessão e local storage
        sessionStorage.clear();
        localStorage.clear();
    }

    mostrarMensagemSucesso() {
        this.ocultarLoading();
        
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        `;
        
        modal.innerHTML = `
            <div style="
                background: #1c1c1c;
                padding: 30px;
                border-radius: 10px;
                border: 2px solid #17d46f;
                max-width: 400px;
                width: 90%;
                text-align: center;
            ">
                <div style="font-size: 3rem; margin-bottom: 20px;">✅</div>
                <h3 style="color: #17d46f; margin-bottom: 15px;">Conta Deletada</h3>
                <p style="color: #ccc; line-height: 1.5; margin-bottom: 20px;">
                    Sua conta foi deletada com sucesso.<br>
                    Você será redirecionado para a página de login.
                </p>
                <div class="loading-spinner" style="border-top-color: #17d46f; margin: 0 auto 20px auto;"></div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Redirecionar para login após 3 segundos
        setTimeout(() => {
            window.location.href = 'IndexLogin.html';
        }, 3000);
    }

    mostrarMensagem(mensagem, tipo = 'info') {
        const cor = tipo === 'erro' ? '#ff4444' : '#d4a017';
        
        // Criar mensagem temporária
        const mensagemElement = document.createElement('div');
        mensagemElement.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #1c1c1c;
            color: ${cor};
            padding: 15px 20px;
            border-radius: 6px;
            border: 1px solid ${cor};
            z-index: 1000;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        mensagemElement.textContent = mensagem;
        
        document.body.appendChild(mensagemElement);
        
        // Remover após 5 segundos
        setTimeout(() => {
            mensagemElement.remove();
        }, 5000);
    }
}

// Funções globais para compatibilidade
function voltar() {
    if (document.referrer && document.referrer.includes(window.location.hostname)) {
        window.history.back();
    } else {
        window.location.href = 'IndexConfiguracoes.html';
    }
}

// Inicialização quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    window.deletarContaManager = new DeletarContaManager();
});