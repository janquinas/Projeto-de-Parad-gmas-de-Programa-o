document.addEventListener('DOMContentLoaded', function() {
    // Script para preview da foto
    const photoUpload = document.getElementById('photo-upload');
    if (photoUpload) {
        photoUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const profilePhoto = document.querySelector('.profile-photo');
                    if (profilePhoto) {
                        profilePhoto.innerHTML = 
                            `<img src="${e.target.result}" alt="Foto do perfil" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
                    }
                }
                reader.readAsDataURL(file);
            }
        });
    }

    // Permitir Enter para salvar cargo
    const cargoInput = document.getElementById('cargo-input');
    if (cargoInput) {
        cargoInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                salvarCargo();
            }
        });
    }
    
    // Configurar botões de ação
    configurarBotoesAcao();
    
    // Carregar dados do usuário
    carregarDadosUsuario();
});

// Função para carregar dados do usuário
function carregarDadosUsuario() {
    // Em uma implementação real, isso viria de uma API
    const dadosUsuario = {
        idEmpresa: 'EMP-2024-001',
        usuario: 'joao.silva',
        email: 'joao.silva@empresa.com',
        turno: 'Seg-Sex | 08:00-17:00',
        cargo: 'Operador de Produção Sênior'
    };
    
    // Salvar email no localStorage para uso em outras páginas
    localStorage.setItem('userEmail', dadosUsuario.email);
}

// Função para salvar cargo
function salvarCargo() {
    const cargoInput = document.getElementById('cargo-input');
    if (!cargoInput) return;
    
    const novoCargo = cargoInput.value.trim();
    if (novoCargo === '') {
        mostrarMensagem('Por favor, insira um cargo válido.', 'erro');
        return;
    }
    
    // Simulação de salvamento
    mostrarMensagem('Cargo atualizado para: ' + novoCargo, 'sucesso');
    
    // Em uma implementação real, aqui faria uma chamada API
    console.log('Cargo salvo:', novoCargo);
}

// Função para sair
function sair() {
    if (confirm('Tem certeza que deseja sair?')) {
        // Limpar dados de sessão
        sessionStorage.clear();
        localStorage.removeItem('userEmail');
        
        // Redirecionar para login
        window.location.href = 'IndexLogin.html';
    }
}

// Função para ir para configurações
function irParaConfiguracoes() {
    window.location.href = 'IndexConfiguracoes.html';
}

// Função para configurar todos os botões de ação
function configurarBotoesAcao() {
    // Botão Sair
    const botoesSair = document.querySelectorAll('.btn-secondary');
    botoesSair.forEach((botao) => {
        if (botao.textContent.trim() === 'Sair') {
            botao.addEventListener('click', sair);
        }
    });
    
    // Botão Ver Dados de Produção
    const btnProducao = document.querySelector('.btn-primary');
    if (btnProducao && btnProducao.textContent.includes('Ver Dados de Produção')) {
        btnProducao.addEventListener('click', function() {
            window.location.href = 'IndexPaginaPrincipal.html';
        });
    }
    
    // Botão Alterar Turno
    const botoesTurno = document.querySelectorAll('.btn-secondary');
    botoesTurno.forEach(botao => {
        if (botao.textContent.trim() === 'Alterar Turno') {
            botao.addEventListener('click', function() {
                window.location.href = 'IndexAlterarTurno.html';
            });
        }
    });
    
    // Botão Configurações (já configurado no HTML via onclick)
}

// Função para mostrar mensagens
function mostrarMensagem(mensagem, tipo = 'info') {
    const cores = {
        sucesso: '#17d46f',
        erro: '#ff4444',
        info: '#d4a017'
    };
    
    const cor = cores[tipo] || cores.info;
    
    // Criar mensagem temporária
    const mensagemElement = document.createElement('div');
    mensagemElement.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #1c1c1c;
        color: ${cor};
        padding: 15px 20px;
        border-radius: 6px;
        border: 1px solid ${cor};
        z-index: 1000;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    mensagemElement.textContent = mensagem;
    
    document.body.appendChild(mensagemElement);
    
    // Remover após 5 segundos
    setTimeout(() => {
        mensagemElement.remove();
    }, 5000);
}
function irParaAlterarTurno() {
    window.location.href = 'IndexAlterarTurno.html';
}

function irParaConfiguracoes() {
    window.location.href = 'IndexConfiguracoes.html';
}