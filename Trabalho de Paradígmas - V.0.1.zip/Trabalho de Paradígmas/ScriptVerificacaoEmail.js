document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form-verificacao');
    const btnReenviar = document.getElementById('reenviar');
    const linkReenviar = document.getElementById('link-reenviar');
    
    // Simular código de verificação (em produção viria do backend)
    const codigoVerificacao = Math.floor(100000 + Math.random() * 900000).toString();
    console.log('Código de verificação (simulação):', codigoVerificacao);
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const codigo = document.getElementById('codigo').value;
        
        if (codigo.trim() === '') {
            alert('Por favor, insira o código de verificação.');
            return;
        }
        
        if (codigo !== codigoVerificacao) {
            alert('Código incorreto. Tente novamente.');
            return;
        }
        
        // Verificar se é recuperação de senha ou alteração de email
        const emailRecuperacao = sessionStorage.getItem('emailRecuperacao');
        const novoEmail = sessionStorage.getItem('novoEmail');
        
        if (emailRecuperacao) {
            // É recuperação de senha
            alert('Email verificado com sucesso! Redirecionando para redefinição de senha...');
            sessionStorage.removeItem('emailRecuperacao');
            window.location.href = 'IndexRedefinirSenha.html';
        } else if (novoEmail) {
            // É alteração de email
            alert('Email alterado com sucesso para: ' + novoEmail);
            sessionStorage.removeItem('novoEmail');
            sessionStorage.removeItem('emailTemporario');
            window.location.href = 'IndexUsuarioComum.html';
        } else {
            // É verificação normal de cadastro
            alert('Email verificado com sucesso!');
            window.location.href = 'IndexLogin.html';
        }
    });
    
    // Função para reenviar o e-mail
    function reenviarEmail() {
        alert('E-mail de verificação reenviado!');
        console.log('Novo código (simulação):', codigoVerificacao);
    }
    
    btnReenviar.addEventListener('click', reenviarEmail);
    linkReenviar.addEventListener('click', reenviarEmail);
});