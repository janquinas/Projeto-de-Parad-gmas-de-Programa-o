// Variáveis globais
let usuarios = [];
let usuarioEditando = null;
let paginaAtual = 1;
const usuariosPorPagina = 10;
let termoBusca = '';

document.addEventListener('DOMContentLoaded', function() {
    carregarUsuarios();
    configurarEventos();
});

function configurarEventos() {
    // Evento de busca ao pressionar Enter
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                buscarUsuarios();
            }
        });
    }

    // Evento do formulário de usuário
    const formUsuario = document.getElementById('form-usuario');
    if (formUsuario) {
        formUsuario.addEventListener('submit', function(e) {
            e.preventDefault();
            salvarUsuario();
        });
    }

    // Fechar modais ao clicar fora
    window.addEventListener('click', function(event) {
        const modalUsuario = document.getElementById('modalUsuario');
        const modalConfirmacao = document.getElementById('modalConfirmacao');
        
        if (event.target === modalUsuario) {
            fecharModalUsuario();
        }
        
        if (event.target === modalConfirmacao) {
            fecharModalConfirmacao();
        }
    });
}

// Carregar dados dos usuários
function carregarUsuarios() {
    // Simulação de dados - em uma aplicação real, isso viria de uma API
    usuarios = [
        {
            id: 1,
            nome: 'João Silva',
            email: 'joao.silva@empresa.com',
            usuario: 'joao.silva',
            cargo: 'Operador de Produção Sênior',
            turno: 'manha',
            permissao: 'usuario',
            status: 'ativo',
            dataCriacao: '2024-01-15'
        },
        {
            id: 2,
            nome: 'Maria Santos',
            email: 'maria.santos@empresa.com',
            usuario: 'maria.santos',
            cargo: 'Supervisora de Produção',
            turno: 'tarde',
            permissao: 'supervisor',
            status: 'ativo',
            dataCriacao: '2024-01-20'
        },
        {
            id: 3,
            nome: 'Pedro Oliveira',
            email: 'pedro.oliveira@empresa.com',
            usuario: 'pedro.oliveira',
            cargo: 'Analista de Qualidade',
            turno: 'noite',
            permissao: 'usuario',
            status: 'ativo',
            dataCriacao: '2024-02-01'
        },
        {
            id: 4,
            nome: 'Ana Costa',
            email: 'ana.costa@empresa.com',
            usuario: 'ana.costa',
            cargo: 'Assistente Administrativo',
            turno: 'administrativo',
            permissao: 'usuario',
            status: 'inativo',
            dataCriacao: '2024-02-10'
        },
        {
            id: 5,
            nome: 'Carlos Lima',
            email: 'carlos.lima@empresa.com',
            usuario: 'carlos.lima',
            cargo: 'Operador de Máquinas',
            turno: 'manha',
            permissao: 'usuario',
            status: 'pendente',
            dataCriacao: '2024-02-15'
        }
    ];

    // Adicionar mais usuários para demonstração
    for (let i = 6; i <= 25; i++) {
        usuarios.push({
            id: i,
            nome: `Usuário ${i}`,
            email: `usuario${i}@empresa.com`,
            usuario: `usuario${i}`,
            cargo: i % 2 === 0 ? 'Operador' : 'Analista',
            turno: ['manha', 'tarde', 'noite'][i % 3],
            permissao: i % 5 === 0 ? 'supervisor' : 'usuario',
            status: ['ativo', 'inativo', 'pendente'][i % 3],
            dataCriacao: `2024-0${Math.floor(i/10) + 1}-${(i % 20) + 1}`
        });
    }

    renderizarUsuarios();
}

// Renderizar tabela de usuários
function renderizarUsuarios() {
    const tbody = document.getElementById('users-table-body');
    if (!tbody) return;

    // Filtrar usuários baseado na busca
    let usuariosFiltrados = usuarios;
    if (termoBusca) {
        usuariosFiltrados = usuarios.filter(usuario => 
            usuario.nome.toLowerCase().includes(termoBusca.toLowerCase()) ||
            usuario.email.toLowerCase().includes(termoBusca.toLowerCase()) ||
            usuario.usuario.toLowerCase().includes(termoBusca.toLowerCase()) ||
            usuario.cargo.toLowerCase().includes(termoBusca.toLowerCase())
        );
    }

    // Calcular paginação
    const totalPaginas = Math.ceil(usuariosFiltrados.length / usuariosPorPagina);
    const inicio = (paginaAtual - 1) * usuariosPorPagina;
    const fim = inicio + usuariosPorPagina;
    const usuariosPagina = usuariosFiltrados.slice(inicio, fim);

    // Atualizar controles de paginação
    atualizarPaginacao(totalPaginas);

    // Renderizar usuários
    tbody.innerHTML = '';
    
    if (usuariosPagina.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 40px;">
                    Nenhum usuário encontrado
                </td>
            </tr>
        `;
        return;
    }

    usuariosPagina.forEach(usuario => {
        const tr = document.createElement('tr');
        
        // Mapear valores para exibição
        const turnoTexto = {
            'manha': 'Manhã (06:00-14:00)',
            'tarde': 'Tarde (14:00-22:00)',
            'noite': 'Noite (22:00-06:00)',
            'administrativo': 'Administrativo (08:00-17:00)'
        }[usuario.turno] || usuario.turno;

        const permissaoTexto = {
            'usuario': 'Usuário Comum',
            'supervisor': 'Supervisor',
            'admin': 'Administrador'
        }[usuario.permissao] || usuario.permissao;

        tr.innerHTML = `
            <td>${usuario.id}</td>
            <td>${usuario.nome}</td>
            <td>${usuario.email}</td>
            <td>${usuario.cargo}</td>
            <td>${turnoTexto}</td>
            <td><span class="status-badge status-${usuario.status}">${usuario.status}</span></td>
            <td class="actions-cell">
                <button class="btn-warning" onclick="editarUsuario(${usuario.id})">Editar</button>
                <button class="btn-danger" onclick="confirmarExclusao(${usuario.id})">Excluir</button>
                ${usuario.status === 'ativo' ? 
                    `<button class="btn-secondary" onclick="alterarStatus(${usuario.id}, 'inativo')">Desativar</button>` :
                    `<button class="btn-primary" onclick="alterarStatus(${usuario.id}, 'ativo')">Ativar</button>`
                }
            </td>
        `;
        
        tbody.appendChild(tr);
    });
}

// Atualizar controles de paginação
function atualizarPaginacao(totalPaginas) {
    const prevBtn = document.getElementById('prev-page');
    const nextBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');

    if (prevBtn && nextBtn && pageInfo) {
        prevBtn.disabled = paginaAtual === 1;
        nextBtn.disabled = paginaAtual === totalPaginas;
        pageInfo.textContent = `Página ${paginaAtual} de ${totalPaginas}`;
    }
}

// Navegação entre páginas
function mudarPagina(direcao) {
    const totalPaginas = Math.ceil(
        termoBusca ? 
        usuarios.filter(u => 
            u.nome.toLowerCase().includes(termoBusca.toLowerCase()) ||
            u.email.toLowerCase().includes(termoBusca.toLowerCase()) ||
            u.usuario.toLowerCase().includes(termoBusca.toLowerCase()) ||
            u.cargo.toLowerCase().includes(termoBusca.toLowerCase())
        ).length : 
        usuarios.length
    ) / usuariosPorPagina;

    const novaPagina = paginaAtual + direcao;
    
    if (novaPagina >= 1 && novaPagina <= totalPaginas) {
        paginaAtual = novaPagina;
        renderizarUsuarios();
    }
}

// Buscar usuários
function buscarUsuarios() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        termoBusca = searchInput.value.trim();
        paginaAtual = 1;
        renderizarUsuarios();
    }
}

// Modal - Novo Usuário
function abrirModalNovoUsuario() {
    usuarioEditando = null;
    
    const modal = document.getElementById('modalUsuario');
    const titulo = document.getElementById('modal-usuario-title');
    const submitBtn = document.getElementById('modal-usuario-submit');
    const form = document.getElementById('form-usuario');
    
    if (modal && titulo && submitBtn && form) {
        titulo.textContent = 'Novo Usuário';
        submitBtn.textContent = 'Criar Usuário';
        form.reset();
        modal.style.display = 'block';
    }
}

// Modal - Editar Usuário
function editarUsuario(id) {
    const usuario = usuarios.find(u => u.id === id);
    if (!usuario) return;

    usuarioEditando = usuario;
    
    const modal = document.getElementById('modalUsuario');
    const titulo = document.getElementById('modal-usuario-title');
    const submitBtn = document.getElementById('modal-usuario-submit');
    
    if (modal && titulo && submitBtn) {
        titulo.textContent = 'Editar Usuário';
        submitBtn.textContent = 'Salvar Alterações';
        
        // Preencher formulário com dados do usuário
        document.getElementById('usuario-nome').value = usuario.nome;
        document.getElementById('usuario-email').value = usuario.email;
        document.getElementById('usuario-cargo').value = usuario.cargo;
        document.getElementById('usuario-usuario').value = usuario.usuario;
        document.getElementById('usuario-turno').value = usuario.turno;
        document.getElementById('usuario-permissao').value = usuario.permissao;
        
        // Esconder campos de senha para edição
        document.getElementById('usuario-senha').closest('.form-group').style.display = 'none';
        document.getElementById('usuario-confirmar-senha').closest('.form-group').style.display = 'none';
        
        modal.style.display = 'block';
    }
}

// Fechar modal de usuário
function fecharModalUsuario() {
    const modal = document.getElementById('modalUsuario');
    if (modal) {
        modal.style.display = 'none';
        // Restaurar campos de senha
        document.getElementById('usuario-senha').closest('.form-group').style.display = 'flex';
        document.getElementById('usuario-confirmar-senha').closest('.form-group').style.display = 'flex';
    }
}

// Salvar usuário (criar ou editar)
function salvarUsuario() {
    const nome = document.getElementById('usuario-nome').value.trim();
    const email = document.getElementById('usuario-email').value.trim();
    const cargo = document.getElementById('usuario-cargo').value.trim();
    const usuario = document.getElementById('usuario-usuario').value.trim();
    const turno = document.getElementById('usuario-turno').value;
    const permissao = document.getElementById('usuario-permissao').value;
    const senha = document.getElementById('usuario-senha').value;
    const confirmarSenha = document.getElementById('usuario-confirmar-senha').value;

    // Validações
    if (!nome || !email || !cargo || !usuario || !turno || !permissao) {
        mostrarMensagem('Por favor, preencha todos os campos obrigatórios.', 'erro');
        return;
    }

    if (!usuarioEditando && (!senha || !confirmarSenha)) {
        mostrarMensagem('Por favor, preencha a senha e confirmação.', 'erro');
        return;
    }

    if (!usuarioEditando && senha !== confirmarSenha) {
        mostrarMensagem('As senhas não coincidem.', 'erro');
        return;
    }

    if (usuarioEditando) {
        // Editar usuário existente
        const index = usuarios.findIndex(u => u.id === usuarioEditando.id);
        if (index !== -1) {
            usuarios[index] = {
                ...usuarios[index],
                nome,
                email,
                cargo,
                usuario,
                turno,
                permissao
            };
            mostrarMensagem('Usuário atualizado com sucesso!', 'sucesso');
        }
    } else {
        // Criar novo usuário
        const novoUsuario = {
            id: Math.max(...usuarios.map(u => u.id)) + 1,
            nome,
            email,
            cargo,
            usuario,
            turno,
            permissao,
            status: 'ativo',
            dataCriacao: new Date().toISOString().split('T')[0]
        };
        usuarios.push(novoUsuario);
        mostrarMensagem('Usuário criado com sucesso!', 'sucesso');
    }

    fecharModalUsuario();
    renderizarUsuarios();
}

// Confirmar exclusão de usuário
function confirmarExclusao(id) {
    const usuario = usuarios.find(u => u.id === id);
    if (!usuario) return;

    const modal = document.getElementById('modalConfirmacao');
    const titulo = document.getElementById('confirmacao-titulo');
    const mensagem = document.getElementById('confirmacao-mensagem');
    const btnConfirmar = document.getElementById('confirmacao-btn');

    if (modal && titulo && mensagem && btnConfirmar) {
        titulo.textContent = 'Confirmar Exclusão';
        mensagem.textContent = `Tem certeza que deseja excluir o usuário "${usuario.nome}"? Esta ação não pode ser desfeita.`;
        
        btnConfirmar.onclick = function() {
            excluirUsuario(id);
            fecharModalConfirmacao();
        };
        
        modal.style.display = 'block';
    }
}

// Excluir usuário
function excluirUsuario(id) {
    usuarios = usuarios.filter(u => u.id !== id);
    mostrarMensagem('Usuário excluído com sucesso!', 'sucesso');
    renderizarUsuarios();
}

// Alterar status do usuário
function alterarStatus(id, novoStatus) {
    const usuario = usuarios.find(u => u.id === id);
    if (!usuario) return;

    const modal = document.getElementById('modalConfirmacao');
    const titulo = document.getElementById('confirmacao-titulo');
    const mensagem = document.getElementById('confirmacao-mensagem');
    const btnConfirmar = document.getElementById('confirmacao-btn');

    if (modal && titulo && mensagem && btnConfirmar) {
        const acao = novoStatus === 'ativo' ? 'ativar' : 'desativar';
        titulo.textContent = `Confirmar ${acao.charAt(0).toUpperCase() + acao.slice(1)}`;
        mensagem.textContent = `Tem certeza que deseja ${acao} o usuário "${usuario.nome}"?`;
        
        btnConfirmar.onclick = function() {
            usuario.status = novoStatus;
            mostrarMensagem(`Usuário ${acao}do com sucesso!`, 'sucesso');
            fecharModalConfirmacao();
            renderizarUsuarios();
        };
        
        modal.style.display = 'block';
    }
}

// Fechar modal de confirmação
function fecharModalConfirmacao() {
    const modal = document.getElementById('modalConfirmacao');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Voltar para o perfil
function voltarParaPerfil() {
    window.location.href = 'IndexPerfilAdm.html';
}

// Mostrar mensagens
function mostrarMensagem(mensagem, tipo = 'info') {
    // Remover mensagens existentes
    const mensagensExistentes = document.querySelectorAll('.mensagem');
    mensagensExistentes.forEach(msg => msg.remove());

    const cores = {
        sucesso: '#28a745',
        erro: '#dc3545',
        info: '#d4a017'
    };

    const cor = cores[tipo] || cores.info;
    
    // Criar mensagem
    const mensagemElement = document.createElement('div');
    mensagemElement.className = `mensagem ${tipo}`;
    mensagemElement.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #1c1c1c;
        color: ${cor};
        padding: 15px 20px;
        border-radius: 6px;
        border: 1px solid ${cor};
        z-index: 1000;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    mensagemElement.textContent = mensagem;
    
    document.body.appendChild(mensagemElement);
    
    // Remover após 5 segundos
    setTimeout(() => {
        mensagemElement.remove();
    }, 5000);
}