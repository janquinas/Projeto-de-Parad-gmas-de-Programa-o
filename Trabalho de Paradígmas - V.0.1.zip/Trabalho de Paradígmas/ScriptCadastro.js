document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form-cadastro');
    const senha = document.getElementById('senha');
    const confirmarSenha = document.getElementById('confirmar-senha');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Verificar se as senhas coincidem
        if (senha.value !== confirmarSenha.value) {
            alert('As senhas não coincidem. Por favor, verifique.');
            confirmarSenha.focus();
            return;
        }
        
        // Verificar se a senha tem pelo menos 8 caracteres
        if (senha.value.length < 8) {
            alert('A senha deve ter pelo menos 8 caracteres.');
            senha.focus();
            return;
        }
        
        // Validar email
        const email = document.getElementById('email').value;
        if (!validarEmail(email)) {
            alert('Por favor, insira um email válido.');
            return;
        }
        
        // Se todas as validações passarem, enviar o formulário
        alert('Cadastro realizado com sucesso! Verifique seu email para confirmação.');
        // form.submit(); // Descomente para enviar para o backend
    });
    
    function validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    
    // Validação em tempo real da confirmação de senha
    confirmarSenha.addEventListener('input', function() {
        if (senha.value !== confirmarSenha.value) {
            confirmarSenha.style.borderColor = '#ff4444';
        } else {
            confirmarSenha.style.borderColor = '#d4a017';
        }
    });
});