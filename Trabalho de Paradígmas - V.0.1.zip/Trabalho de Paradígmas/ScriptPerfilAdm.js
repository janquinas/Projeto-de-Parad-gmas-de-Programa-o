document.addEventListener('DOMContentLoaded', function() {
    // Script para preview da foto
    const photoUpload = document.getElementById('photo-upload');
    if (photoUpload) {
        photoUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const profilePhoto = document.querySelector('.profile-photo');
                    if (profilePhoto) {
                        profilePhoto.innerHTML = 
                            `<img src="${e.target.result}" alt="Foto do perfil" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
                    }
                }
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Configurar botões de ação
    configurarBotoesAcao();
    
    // Carregar dados do administrador
    carregarDadosAdm();
    
    // Configurar eventos dos modais
    configurarModais();
});

// Função para carregar dados do administrador
function carregarDadosAdm() {
    // Em uma implementação real, isso viria de uma API
    const dadosAdm = {
        idEmpresa: 'EMP-2024-001',
        usuario: 'admin.empresa',
        email: 'admin@empresa.com',
        nivelAcesso: 'Administrador'
    };
    
    // Salvar dados no localStorage para uso em outras páginas
    localStorage.setItem('userEmail', dadosAdm.email);
    localStorage.setItem('userRole', 'admin');
}

// Função para sair
function sair() {
    if (confirm('Tem certeza que deseja sair?')) {
        // Limpar dados de sessão
        sessionStorage.clear();
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userRole');
        
        // Redirecionar para login
        window.location.href = 'IndexLogin.html';
    }
}

// Função para configurar todos os botões de ação
function configurarBotoesAcao() {
    // Botão Sair
    const botoesSair = document.querySelectorAll('.btn-secondary');
    botoesSair.forEach((botao) => {
        if (botao.textContent.trim() === 'Sair') {
            botao.addEventListener('click', sair);
        }
    });
}

// Função para mostrar mensagens
function mostrarMensagem(mensagem, tipo = 'info') {
    const cores = {
        sucesso: '#17d46f',
        erro: '#ff4444',
        info: '#d4a017'
    };
    
    const cor = cores[tipo] || cores.info;
    
    // Criar mensagem temporária
    const mensagemElement = document.createElement('div');
    mensagemElement.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #1c1c1c;
        color: ${cor};
        padding: 15px 20px;
        border-radius: 6px;
        border: 1px solid ${cor};
        z-index: 1000;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    mensagemElement.textContent = mensagem;
    
    document.body.appendChild(mensagemElement);
    
    // Remover após 5 segundos
    setTimeout(() => {
        mensagemElement.remove();
    }, 5000);
}

// Funções para navegação
function irParaDadosEmpresa() {
    window.location.href = 'IndexDadosEmpresa.html';
}

function irParaGerenciarUsuarios() {
    window.location.href = 'IndexGerenciarUsuarios.html';
}

// Funções para os modais
function configurarModais() {
    // Configurar evento para mostrar período personalizado
    const periodoRelatorio = document.getElementById('periodoRelatorio');
    if (periodoRelatorio) {
        periodoRelatorio.addEventListener('change', function() {
            const periodoPersonalizado = document.getElementById('periodoPersonalizado');
            if (this.value === 'personalizado') {
                periodoPersonalizado.style.display = 'block';
            } else {
                periodoPersonalizado.style.display = 'none';
            }
        });
    }
    
    // Fechar modal ao clicar fora dele
    window.addEventListener('click', function(event) {
        const modalRelatorio = document.getElementById('modalRelatorio');
        const modalMensagem = document.getElementById('modalMensagem');
        
        if (event.target === modalRelatorio) {
            fecharModalRelatorio();
        }
        
        if (event.target === modalMensagem) {
            fecharModalMensagem();
        }
    });
}

// Funções para abrir e fechar modais
function abrirModalRelatorio() {
    document.getElementById('modalRelatorio').style.display = 'block';
}

function fecharModalRelatorio() {
    document.getElementById('modalRelatorio').style.display = 'none';
}

function abrirModalMensagem() {
    document.getElementById('modalMensagem').style.display = 'block';
}

function fecharModalMensagem() {
    document.getElementById('modalMensagem').style.display = 'none';
}

// Função para gerar relatório
function gerarRelatorio() {
    const tipoRelatorio = document.getElementById('tipoRelatorio').value;
    const periodoRelatorio = document.getElementById('periodoRelatorio').value;
    const formato = document.querySelector('input[name="formato"]:checked').value;
    
    let periodoTexto = periodoRelatorio;
    
    // Se for período personalizado, obter as datas
    if (periodoRelatorio === 'personalizado') {
        const dataInicio = document.getElementById('dataInicio').value;
        const dataFim = document.getElementById('dataFim').value;
        
        if (!dataInicio || !dataFim) {
            mostrarMensagem('Por favor, preencha as datas para o período personalizado.', 'erro');
            return;
        }
        
        periodoTexto = `de ${formatarData(dataInicio)} a ${formatarData(dataFim)}`;
    }
    
    // Simulação de geração de relatório
    mostrarMensagem(`Relatório ${tipoRelatorio} (${periodoTexto}) gerado em formato ${formato.toUpperCase()}`, 'sucesso');
    
    // Em uma implementação real, aqui faria uma chamada API
    console.log('Relatório solicitado:', {
        tipo: tipoRelatorio,
        periodo: periodoTexto,
        formato: formato
    });
    
    // Fechar modal após gerar relatório
    fecharModalRelatorio();
}

// Função para enviar mensagem
function enviarMensagem() {
    const destinatario = document.getElementById('destinatario').value;
    const assunto = document.getElementById('assuntoMensagem').value.trim();
    const conteudo = document.getElementById('conteudoMensagem').value.trim();
    
    if (!assunto || !conteudo) {
        mostrarMensagem('Por favor, preencha o assunto e o conteúdo da mensagem.', 'erro');
        return;
    }
    
    // Simulação de envio de mensagem
    mostrarMensagem(`Mensagem enviada para ${destinatario === 'todos' ? 'todos os usuários' : destinatario}`, 'sucesso');
    
    // Em uma implementação real, aqui faria uma chamada API
    console.log('Mensagem enviada:', {
        destinatario: destinatario,
        assunto: assunto,
        conteudo: conteudo
    });
    
    // Fechar modal após enviar mensagem
    fecharModalMensagem();
    
    // Limpar campos
    document.getElementById('assuntoMensagem').value = '';
    document.getElementById('conteudoMensagem').value = '';
}

// Função auxiliar para formatar data
function formatarData(dataString) {
    const data = new Date(dataString);
    return data.toLocaleDateString('pt-BR');
}