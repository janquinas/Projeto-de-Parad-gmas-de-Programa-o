﻿using controle_de_qualidade_metalúrgica.Backend_DOTNET.Models;

namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Controller
{
    public class UsuarioController
    {
        public class UsuarioController
        {
            // Simulação de um "banco de dados" de usuários
            private List<Usuario> _usuarios = new List<Usuario>();

            // Método que simula a ação de "Login"
            public bool Login(string email, string senha)
            {
                // login.
                var usuario = _usuarios.Find(u => u.Email == email && u.Senha == senha);

                if (usuario != null)
                {
                    Console.WriteLine($"Usuário {usuario.NomeCompleto} logado com sucesso!");
                    return true;
                }
                else
                {
                    Console.WriteLine("Credenciais inválidas.");
                    return false;
                }
            }


            public void Cadastrar(Cadastro novoCadastro)
            {
                // Fru fru de verificar email
                if (!novoCadastro.Email.EndsWith("@gmail.com"))
                {
                    Console.WriteLine("Cadastro negado. Email inválido.");
                    return;
                }
.
                var novoUsuario = new Usuario
                {
                    IdDoUsuario = _usuarios.Count + 1, // ID = 1 
                    NomeCompleto = novoCadastro.NomeCompleto,
                    Email = novoCadastro.Email,
                    Cargo = novoCadastro.Cargo,
                    Senha = novoCadastro.Senha
                };

                _usuarios.Add(novoUsuario);
                Console.WriteLine($"Novo usuário {novoUsuario.NomeCompleto} cadastrado!");
            }
        }
    }
}
