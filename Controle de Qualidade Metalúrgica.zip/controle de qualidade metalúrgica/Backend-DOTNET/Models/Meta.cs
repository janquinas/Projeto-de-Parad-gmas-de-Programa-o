﻿namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Models
{
    public class Meta
    {
        public string IdDoPedido { get; set; }
        public string Empresa { get; set; }
        public string Material { get; set; }
        public double Espessura { get; set; }
        public double Data { get; set; }
        public double Prazo { get; set; }
        public int MetaDiaria { get; set; }s
    }
}
