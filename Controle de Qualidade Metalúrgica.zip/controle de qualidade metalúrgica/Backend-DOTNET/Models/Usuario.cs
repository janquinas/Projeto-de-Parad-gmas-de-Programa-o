﻿namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Models
{
    public class Usuario
    {
        public int IdDoUsuario { get; set; }
        public string NomeCompleto { get; set; }
        public string Email { get; set; }
        public string Cargo { get; set; } // Boon para cargo ja que so tem 2(peão e chefe)
        public string Senha { get; set; }
    }
}
