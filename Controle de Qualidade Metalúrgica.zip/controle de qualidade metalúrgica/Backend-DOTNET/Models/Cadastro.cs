﻿namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Models
{
    public class Cadastro
    {
        public int IdDoUsuario { get; set; } // Gerado automaticamente
        public string NomeCompleto { get; set; }
        public string Email { get; set; }
        public string Cargo { get; set; }
        public string Senha { get; set; }
    }
}
}
