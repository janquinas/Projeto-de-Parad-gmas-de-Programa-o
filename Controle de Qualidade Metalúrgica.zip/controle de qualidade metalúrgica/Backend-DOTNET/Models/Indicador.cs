﻿namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Models
{
    public class Indicador
    {
    public double Produtividade { get; set; }
    public double TaxaDeDefeitos { get; set; }
    public double OEE { get; set; }
    }
}
