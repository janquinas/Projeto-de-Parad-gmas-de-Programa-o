﻿namespace controle_de_qualidade_metalúrgica.Backend_DOTNET.Models
{
    public class Producao
    {
        public string CodigoDoPedido { get; set; }
        public string Empresa { get; set; }
        public string Material { get; set; }
        public double Espessura { get; set; }
        public double CalculoTeorico { get; set; }
        public DateTime DataDeInicio { get; set; }
        public DateTime Prazo { get; set; }
        public string Turno { get; set; }
        public int QuantidadeProduzida { get; set; }
        public int MateriaisDisponiveis { get; set; }
        public string ProblemaReportado { get; set; } // Opcional
        public bool ProducaoFinalizada { get; set; }
        public string Status { get; set; }
    }
}
